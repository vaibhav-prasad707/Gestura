"use client"

import AuthPage from "../auth-page"

export default function SyntheticV0PageForDeployment() {
  return <AuthPage />
}