import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Github, Mail } from "lucide-react"

export default function AuthPage() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-purple-950 via-blue-950 to-slate-950">
      <div className="relative w-full max-w-md p-8 rounded-xl bg-black/20 backdrop-blur-sm border border-purple-500/10">
        {/* Glowing orb effects */}
        <div className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-purple-500/20 blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-40 h-40 rounded-full bg-blue-500/20 blur-3xl" />

        {/* Content */}
        <div className="relative space-y-6">
          <div className="space-y-2 text-center">
            <h1 className="text-2xl font-bold tracking-tight text-white">Welcome back</h1>
            <p className="text-gray-400">Sign in to your account to continue</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-200">
                Email
              </Label>
              <Input
                id="email"
                placeholder="name@example.com"
                type="email"
                className="bg-white/5 border-purple-500/20 text-white placeholder:text-gray-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-gray-200">
                Password
              </Label>
              <Input id="password" type="password" className="bg-white/5 border-purple-500/20 text-white" />
            </div>
            <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
              Sign In
            </Button>
          </div>

          <div className="relative">
            <Separator className="my-4 bg-purple-500/20" />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="px-2 text-xs text-gray-400 bg-gradient-to-br from-purple-950 via-blue-950 to-slate-950">
                Or continue with
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="bg-white/5 border-purple-500/20 text-white hover:bg-white/10">
              <Mail className="w-4 h-4 mr-2" />
              Gmail
            </Button>
            <Button variant="outline" className="bg-white/5 border-purple-500/20 text-white hover:bg-white/10">
              <Github className="w-4 h-4 mr-2" />
              GitHub
            </Button>
          </div>

          <div className="text-center">
            <a href="#" className="text-sm text-purple-400 hover:text-purple-300">
              Forgot your password?
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

