"use client"

import ChatPage from "../chat-page"

export default function SyntheticV0PageForDeployment() {
  return <ChatPage />
}