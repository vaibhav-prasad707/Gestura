"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { AlertCircle, Mic, MicOff, Send, Volume2, Loader2 } from "lucide-react"

interface Message {
  id: string
  text: string
  sender: string
  timestamp: string
  isUser: boolean
}

export default function ChatPage() {
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [isSpeakerOff, setIsSpeakerOff] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello team! I've added some new accessibility features to our project.",
      sender: "Alex",
      timestamp: "11:30 AM",
      isUser: false,
    },
    {
      id: "2",
      text: "That's great! Can you tell us more about them?",
      sender: "You",
      timestamp: "11:32 AM",
      isUser: true,
    },
  ])
  const [isListening, setIsListening] = useState(false)
  const [inputValue, setInputValue] = useState("")
  const recognition = useRef<SpeechRecognition | null>(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      // Initialize speech recognition
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      if (SpeechRecognition) {
        recognition.current = new SpeechRecognition()
        recognition.current.continuous = true
        recognition.current.interimResults = true

        recognition.current.onresult = (event) => {
          const transcript = Array.from(event.results)
            .map((result) => result[0])
            .map((result) => result.transcript)
            .join("")

          setInputValue(transcript)
        }

        recognition.current.onerror = (event) => {
          console.error("Speech recognition error:", event.error)
          setIsListening(false)
        }

        recognition.current.onend = () => {
          setIsListening(false)
        }
      }
    }
  }, [])

  const toggleListening = () => {
    if (isListening) {
      recognition.current?.stop()
      setIsListening(false)
    } else {
      recognition.current?.start()
      setIsListening(true)
    }
  }

  const handleSendMessage = () => {
    if (inputValue.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: inputValue,
        sender: "You",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        isUser: true,
      }
      setMessages((prev) => [...prev, newMessage])
      setInputValue("")
    }
  }

  return (
    <div className="flex h-screen bg-[#1b1839]">
      {/* Sidebar */}
      <aside className="w-64 border-r border-[#343c4b]" aria-label="Navigation sidebar">
        <div className="p-4 border-b border-[#343c4b]">
          <h1 className="text-xl font-semibold text-[#cf9cd5]">Accessible Chat</h1>
        </div>
        <Tabs defaultValue="chat" className="w-full" orientation="vertical">
          <TabsList className="flex flex-col h-auto p-0 bg-transparent">
            <TabsTrigger
              value="chat"
              className="w-full justify-start p-4 data-[state=active]:bg-[#cf9cd5] text-[#8c94a2] hover:text-[#cf9cd5] data-[state=active]:text-[#1b1839]"
              aria-label="Chat conversations"
            >
              Conversations
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="w-full justify-start p-4 data-[state=active]:bg-[#cf9cd5] text-[#8c94a2] hover:text-[#cf9cd5] data-[state=active]:text-[#1b1839]"
              aria-label="Accessibility settings"
            >
              Accessibility Settings
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col">
        {/* Chat Header */}
        <header className="border-b border-[#343c4b] p-4 flex items-center justify-between" aria-label="Chat controls">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8 bg-[#745b86]">
              <AvatarImage src="/placeholder.svg" alt="Team chat" />
              <AvatarFallback className="text-[#cf9cd5]">TC</AvatarFallback>
            </Avatar>
            <h2 className="font-semibold text-[#cf9cd5]">Team Chat</h2>
          </div>

          <TooltipProvider>
            <div className="flex items-center gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsMuted(!isMuted)}
                    aria-label={isMuted ? "Unmute microphone" : "Mute microphone"}
                    className="text-[#8c94a2] hover:bg-[#493761] hover:text-[#cf9cd5]"
                  >
                    {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent className="bg-[#343c4b] text-[#cf9cd5]">
                  {isMuted ? "Unmute microphone" : "Mute microphone"}
                </TooltipContent>
              </Tooltip>

              {/* Other controls follow same pattern */}
            </div>
          </TooltipProvider>
        </header>

        {/* Messages Area */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <Card
                key={message.id}
                className={`p-4 max-w-[80%] ${
                  message.isUser ? "ml-auto bg-[#493761] border-[#686269]" : "bg-[#8974a6] border-[#686269]"
                }`}
                role="article"
                aria-label={`Message from ${message.sender}`}
              >
                <div className={`flex items-start gap-2 ${message.isUser ? "flex-row-reverse" : ""}`}>
                  <Avatar className="h-8 w-8 bg-[#745b86]">
                    <AvatarImage src="/placeholder.svg" alt="" />
                    <AvatarFallback className="text-[#cf9cd5]">{message.sender[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className={`flex items-center gap-2 ${message.isUser ? "justify-end" : ""}`}>
                      <span className={`font-semibold ${message.isUser ? "text-[#cf9cd5]" : "text-[#343c4b]"}`}>
                        {message.sender}
                      </span>
                      <span className={`text-sm ${message.isUser ? "text-[#8c94a2]" : "text-[#444046]"}`}>
                        {message.timestamp}
                      </span>
                    </div>
                    <p className={`text-sm mt-1 ${message.isUser ? "text-[#cf9cd5]" : "text-[#1b1839]"}`}>
                      {message.text}
                    </p>
                    {!message.isUser && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="mt-2 text-[#343c4b] hover:bg-[#493761] hover:text-[#cf9cd5]"
                      >
                        <Volume2 className="h-4 w-4 mr-2" />
                        Listen
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </ScrollArea>

        {/* Message Input */}
        <footer className="p-4 border-t border-[#343c4b]">
          <div className="flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSendMessage()
                }
              }}
              placeholder="Type a message or use voice input..."
              className="flex-1 bg-[#343c4b] border-[#444046] text-[#cf9cd5] placeholder-[#686269]"
              aria-label="Message input"
            />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label={isListening ? "Stop voice input" : "Start voice input"}
                    className={`text-[#8c94a2] hover:bg-[#493761] hover:text-[#cf9cd5] ${
                      isListening ? "bg-[#493761] text-[#cf9cd5]" : ""
                    }`}
                    onClick={toggleListening}
                  >
                    {isListening ? (
                      <div className="relative">
                        <Mic className="h-5 w-5" />
                        <div className="absolute -top-1 -right-1">
                          <Loader2 className="h-3 w-3 animate-spin" />
                        </div>
                      </div>
                    ) : (
                      <Mic className="h-5 w-5" />
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent className="bg-[#343c4b] text-[#cf9cd5]">
                  {isListening ? "Stop voice input" : "Start voice input"}
                </TooltipContent>
              </Tooltip>
              <Button
                variant="default"
                size="icon"
                aria-label="Send message"
                className="bg-[#745b86] hover:bg-[#8974a6] text-[#cf9cd5]"
                onClick={handleSendMessage}
              >
                <Send className="h-5 w-5" />
              </Button>
            </TooltipProvider>
          </div>
          <div className="mt-2 flex items-center gap-2 text-sm text-[#686269]">
            <AlertCircle className="h-4 w-4" />
            <span>
              {isListening
                ? "Listening... Click the microphone button to stop"
                : "Press Enter to send, Shift + Enter for new line, or use voice input"}
            </span>
          </div>
        </footer>
      </main>
    </div>
  )
}

